#!/bin/bash
func(){
 echo "=============================="
 date
 echo "=============================="
}
func >>/home/ec2-user/output.txt
echo "                                                        " >>/home/ec2-user/output.txt
echo "********************************************************" >>/home/ec2-user/output.txt
echo "Instance is built by DevOps team, Instance configuration/specs are mentioned below...!" >>/home/ec2-user/output.txt
host=$(hostname)
echo "   The server name is $host" >>/home/ec2-user/output.txt
hostname=$(hostnamectl |grep Operating)
echo " $hostname" >>/home/ec2-user/output.txt
echo "   The installed Application : Jboss" >>/home/ec2-user/output.txt

chmod 777 output.txt
################################################

