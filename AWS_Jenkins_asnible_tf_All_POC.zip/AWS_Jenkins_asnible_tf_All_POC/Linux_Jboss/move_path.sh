#!/bin/bash
IP=$(head -n 1 inventory)
scp -i /root/SandboxToolsKeyPair.pem -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -r ec2-user@$IP:/home/ec2-user/output.txt /home/ec2-user/
mv /home/ec2-user/output.txt /var/lib/jenkins/workspace/Linux_Jboss_Installation/Linux_Jboss/

#####################################
