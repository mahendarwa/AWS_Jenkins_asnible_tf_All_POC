#!/bin/bash
while [[ $(/usr/local/bin/aws ec2 describe-instance-status --instance-id $(cat instance_id) --query 'InstanceStatuses[0]. InstanceStatus.Details[0].Status' --output text) != "passed" ]]; do
  echo -e "Waiting for Instance Status Passed..."
  sleep 1
  while [[ $(/usr/local/bin/aws ec2 describe-instance-status --instance-id $(cat instance_id) --query 'InstanceStatuses[0].SystemStatus.Details[0].Status' --output text) !=  "passed" ]]; do
  echo -e "Waiting for System Status Passed..."
  sleep 1
  done
done