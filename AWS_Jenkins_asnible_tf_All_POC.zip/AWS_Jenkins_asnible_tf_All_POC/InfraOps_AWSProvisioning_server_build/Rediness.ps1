do
{
    if(!(Test-Path -Path "C:\ProgramData\Amazon\SSM\Logs\AmazonSSMAgent-update.txt" ))
    {
        $boolw="false"
    }
    else
    {
        if(select-string -path "C:\ProgramData\Amazon\SSM\Logs\AmazonSSMAgent-update.txt" -Pattern "Initiating update health check")
        {
            Write-Host "Windows is ready for external use" 
            $boolw= "true"
        }
        else
        {
            $boolw="false"
        }
    }
}
while ($boolw -ne "true")