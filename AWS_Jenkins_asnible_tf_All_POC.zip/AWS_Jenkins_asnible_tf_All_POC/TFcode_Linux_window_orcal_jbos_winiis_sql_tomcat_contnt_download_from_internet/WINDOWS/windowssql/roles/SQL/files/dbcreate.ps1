Import SQL Server Module called SQLPS
Import-Module SQLPS -DisableNameChecking

#Your SQL Server Instance Name
$Inst = "localhost\MSSQLSERVERNEW"
$Srvr = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -ArgumentList $Inst

#database PSDB with default settings
#by assuming that this database does not yet exist in current instance
$DBName = "myfirstdb"
$db = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Database($Srvr, $DBName)
$db.Create()
